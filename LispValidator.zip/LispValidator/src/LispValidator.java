import java.util.Scanner;

public class LispValidator
{
    public static void main(String[] args)
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter the LISP Code to validate: ");

        String lispCd = scan.nextLine();

        if(lispCd != null && lispCd.trim().length() > 0)
        {
            System.out.println(validateLisp(lispCd.trim()));
        }
        else
        {
            System.out.println("No code was entered. Goodbye.");
        }
    }

    private static boolean validateLisp(String lispCd)
    {
        int parenCount = 0;

        for(int i = 0; i < lispCd.length(); i++)
        {
            if('(' == (lispCd.charAt(i)))
            {
                parenCount++;
            }
            else if(')' == (lispCd.charAt(i)))
            {
                parenCount--;
            }

            //Too many ending parentheses
            if(parenCount < 0)
            {
                return false;
            }
        }

        //Return true for a valid LISP Code
        //Return false for a code with more opening parentheses than closing.
        return parenCount == 0;
    }
}
